# logger
This is a logger, easy to use
